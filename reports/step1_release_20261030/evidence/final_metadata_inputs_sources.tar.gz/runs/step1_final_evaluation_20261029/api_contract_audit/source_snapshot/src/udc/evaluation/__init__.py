"""UDC evaluation components."""
