"""UDC visualization components."""
